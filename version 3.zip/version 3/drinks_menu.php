<?php
$con = mysqli_connect("localhost", "familtonmi", 'quietfruit45', "familtonmi_tuck_shop");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL:" . mysqli_connect_error();
    die();
} else {
    echo "connected to database";
}
if (isset($_GET['drinks'])) {
    $id = $_GET['drinks'];
} else {
    $id = 1;
}

/* Drinks Query */
$this_drink_query = "SELECT * FROM `drinks` WHERE drink_id = '" . $id . "'";
$this_drink_result = mysqli_query($con, $this_drink_query);
$this_drink_record = mysqli_fetch_assoc($this_drink_result);
/* SELECT DrinkID, Item FROM drinks */
$all_drinks_query = "SELECT * FROM `drinks` WHERE drink_id";
$all_drinks_results = mysqli_query($con, $all_drinks_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>TEAL TUCK SHOP</title>
    <meta charset="utf-8">
    <link rel='stylesheet' type='text/css' href='styles.css'>
</head>

<body>
<header>
    <h1> TEAL TUCK SHOP </h1>
    <nav>
        <ul>
            <a href='index.php'> Home </a>
            <a href='drinks_menu.php'> Drinks </a>
            <a href='food_menu.php'> Food </a>
            <a href='special_food.php'> Food Specials </a>
            <a href='special_drink.php'> Drink Specials </a>
        </ul>
    </nav>
</header>
<main>

    <h2> Search </h2>
    <form action="" method="post">
        <input type="text" name="search">
        <input type="submit" name="submit" value="Search">
    </form>
    <?php
    if (isset($_POST['search'])) {
        $search = $_POST['search'];

        $query1 = "SELECT * FROM drinks WHERE Item LIKE '%$search%'";
        $query = mysqli_query($con, $query1);
        $count = mysqli_num_rows($query);

        if ($count == 0) {
            echo "There was no search results!";

        } else {

            while ($row = mysqli_fetch_array($query)) {

                echo $row ['Item'];
                echo "<br>";
            }
        }
    }
    ?>
    <!--Button to Show Specials-->
    <form action="foodspecials.php" method="post">
        <input type='submit' name='mondayspecial' value="Show Monday's Special">
        <br>
        <?php
        if (isset($_POST['mondayspecial'])) {
            // Query for displaying the food item on special on Friday
            $result = mysqli_query($con, "SELECT food_special.FoodspecialID,food.item,food_special.Day,food_special.Foodspecialprice 
            FROM food_special,food WHERE food.FoodID=foodspecials.food_id AND FoodspecialID= 1");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['FoodspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Food_id'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Foodspecialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }
        }
        ?>
    </form>
    <input type='submit' name='drinks_button' value='Show me the drink information.'>
    </form>
</main>
</body>
</html>
