<?php
$con = mysqli_connect("localhost", "familtonmi", 'quietfruit45', "familtonmi_tuck_shop");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL:" . mysqli_connect_error();
    die();
} else {
    echo "connected to database";
}
if (isset($_GET['drinks'])) {
    $id = $_GET['drinks'];
} else {
    $id = 1;
}

/* Drinks Query */
$this_drink_query = "SELECT * FROM `drinks` WHERE drink_id = '" . $id . "'";
$this_drink_result = mysqli_query($con, $this_drink_query);
$this_drink_record = mysqli_fetch_assoc($this_drink_result);
/* SELECT DrinkID, Item FROM drinks */
$all_drinks_query = "SELECT * FROM `drinks` WHERE drink_id";
$all_drinks_results = mysqli_query($con, $all_drinks_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>TEAL TUCK SHOP</title>
    <meta charset="utf-8">
    <link rel='stylesheet' type='text/css' href='styles.css'>
</head>

<body>
<header>
    <h1> TEAL TUCK SHOP </h1>
    <nav>
        <ul>
            <a href='index.php'> Home </a>
            <a href='drinks_menu.php'> Drinks </a>
            <a href='food_menu.php'> Food </a>
            <a href='special_food.php'> Food Specials </a>
            <a href='special_drink.php'> Drink Specials </a>
        </ul>
    </nav>
</header>
<main>
    <h2> THE WEEK SPECIAL </h2>
    <!--Button to Show Specials-->

    <form action="special_drink.php" method="post">
        <input type='submit' name='mondaysspecial' value="Show Monday's Special">
        <br>
        <?php
        if (isset($_POST['mondaysspecial'])) {
            // Query for displaying the food item on special on monday
            $result = mysqli_query($con, "SELECT drink_special.DrinkspecialID,drinks.item,drink_special.Day,drink_special.Specialprice, drinks.drink_id FROM drink_special,drinks WHERE drinks.drink_id=drink_special.drink_id AND DrinkspecialID= 1");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['DrinkspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['item'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Specialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }

        }
        ?>
    </form>

    <form action="special_drink.php" method="post">
        <input type='submit' name='tuesdaysspecial' value="Show Tuesday's Special">
        <br>
        <?php
        if (isset($_POST['tuesdaysspecial'])) {
            // Query for displaying the food item on special on tuesday
            $result = mysqli_query($con, "SELECT drink_special.DrinkspecialID,drinks.item,drink_special.Day,drink_special.Specialprice, drinks.drink_id FROM drink_special,drinks WHERE drinks.drink_id=drink_special.drink_id AND DrinkspecialID= 2");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['DrinkspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['item'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Specialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }

        }
        ?>
    </form>

    <form action="special_drink.php" method="post">
        <input type='submit' name='wednesdaysspecial' value="Show Wednesday's Special">
        <br>
        <?php
        if (isset($_POST['wednesdaysspecial'])) {
            // Query for displaying the food item on special on wednesday
            $result = mysqli_query($con, "SELECT drink_special.DrinkspecialID,drinks.item,drink_special.Day,drink_special.Specialprice, drinks.drink_id FROM drink_special,drinks WHERE drinks.drink_id=drink_special.drink_id AND DrinkspecialID= 3");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['DrinkspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['item'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Specialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }

        }
        ?>
    </form>

    <form action="special_drink.php" method="post">
        <input type='submit' name='thursdaysspecial' value="Show Thursday's Special">
        <br>
        <?php
        if (isset($_POST['thursdaysspecial'])) {
            // Query for displaying the food item on special on thursday
            $result = mysqli_query($con, "SELECT food_special.FoodspecialID,food.item,food_special.Day,food_special.Foodspecialprice, food.food_id FROM food_special,food WHERE food.food_id=food_special.food_id AND FoodspecialID= 4");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['DrinkspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['item'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Specialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }

        }
        ?>
    </form>

    <form action="special_drink.php" method="post">
        <input type='submit' name='fridaysspecial' value="Show Friday's Special">
        <br>
        <?php
        if (isset($_POST['fridaysspecial'])) {
            // Query for displaying the food item on special on friday
            $result = mysqli_query($con, "SELECT food_special.FoodspecialID,food.item,food_special.Day,food_special.Foodspecialprice, food.food_id FROM food_special,food WHERE food.food_id=food_special.food_id AND FoodspecialID= 5");
            if (mysqli_num_rows($result) != 0) {
                while ($test = mysqli_fetch_array($result)) {
                    $id = $test['DrinkspecialID'];
                    echo "<table>";
                    echo "<tr>";
                    echo "<tr>" . $test['Day'] . "</tr>", "<br>";
                    echo "<tr>" . $test['item'] . "</tr>", "<br>";
                    echo "<tr>" . $test['Specialprice'] . "</tr>";
                    echo "</tr>";
                    echo "</table>";
                }
            }

        }
        ?>
    </form>
</main>
</body>
</html>
