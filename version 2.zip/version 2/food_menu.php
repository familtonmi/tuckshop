<?php
$con = mysqli_connect("localhost", "familtonmi", 'quietfruit45', "familtonmi_tuck_shop");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL:" . mysqli_connect_error();
    die();
} else {
    echo "connected to database";
}
if (isset($_GET['food'])) {
    $id = $_GET['food'];
} else {
    $id = 1;
}

/* Food Query */
$this_food_query = "SELECT * FROM `food` WHERE food_id = '" . $id . "'";
$this_food_result = mysqli_query($con, $this_food_query);
$this_food_record = mysqli_fetch_assoc($this_food_result);
/* SELECT food_id, Item FROM food */
$all_food_query = "SELECT * FROM `food` WHERE food_id";
$all_food_result = mysqli_query($con, $all_food_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>TEAL TUCK SHOP</title>
    <meta charset="utf-8">
    <link rel='stylesheet' type='text/css' href='styles.css'>
</head>

<body>
<header>
    <h1> TEAL TUCK SHOP </h1>
    <nav>
        <ul>
            <a href='index.php'> Home </a>
            <a href='drinks_menu.php'> Drinks </a>
            <a href='food_menu.php'> Food </a>
            <a href='meal_menu.php'> Specials </a>
        </ul>
    </nav>
</header>
<main>
    <h2> Food Information </h2>
    <?php
    echo "<p> Food Name: " . $this_food_record['item'] . "<br>";
    echo "<p> Price: $" . $this_food_record['price'] . "<br>";
    echo "<p> Calories: " . $this_food_record['calories'] . "<br>";
    echo "<p> Temperature: " . $this_food_record['temperature'] . "<br>";
    echo "<p> Stock: " . $this_food_record['stock'] . "<br>";

    ?>
    <h2> Select Another Food Item </h2>
    <!-- DRINKS FORM -->
    <form name='food_form' id='food_form' method='get' action='food_menu.php'>
        <select id='food' name='food'>
            <!-- options -->
            <?php
            while ($all_food_record = mysqli_fetch_assoc($all_food_result)) {
                echo "<option value = '" . $all_food_record['food_id'] . "'>";
                echo $all_food_record['item'];
                echo "</option>";
            }
            ?>
        </select>
        <input type='submit' name='drinks_button' value='Show me the food information.'>
    </form>
</main>
</body>
</html>
