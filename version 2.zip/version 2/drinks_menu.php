<?php
$con = mysqli_connect("localhost", "familtonmi", 'quietfruit45', "familtonmi_tuck_shop");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL:" . mysqli_connect_error();
    die();
} else {
    echo "connected to database";
}
if (isset($_GET['drinks'])) {
    $id = $_GET['drinks'];
} else {
    $id = 1;
}

/* Drinks Query */
$this_drink_query = "SELECT * FROM `drinks` WHERE drink_id = '" . $id . "'";
$this_drink_result = mysqli_query($con, $this_drink_query);
$this_drink_record = mysqli_fetch_assoc($this_drink_result);
/* SELECT DrinkID, Item FROM drinks */
$all_drinks_query = "SELECT * FROM `drinks` WHERE drink_id";
$all_drinks_results = mysqli_query($con, $all_drinks_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>TEAL TUCK SHOP</title>
    <meta charset="utf-8">
    <link rel='stylesheet' type='text/css' href='styles.css'>
</head>

<body>
<header>
    <h1> TEAL TUCK SHOP </h1>
    <nav>
        <ul>
            <a href='index.php'> Home </a>
            <a href='drinks_menu.php'> Drinks </a>
            <a href='food_menu.php'> Food </a>
            <a href='meal_menu.php'> Specials </a>
        </ul>
    </nav>
</header>
<main>
    <h2> Drink Information </h2>
    <?php
    echo "<p> Drink Name: " . $this_drink_record['Item'] . "<br>";
    echo "<p> Price: $" . $this_drink_record['price'] . "<br>";
    echo "<p> Calories: " . $this_drink_record['calories'] . "<br>";
    echo "<p> Temperature: " . $this_drink_record['temperature'] . "<br>";
    echo "<p> Stock: " . $this_drink_record['stock'] . "<br>";

    ?>
    <h2> Select Another Drink </h2>
    <!-- DRINKS FORM -->
    <form name='drinks_form' id='drinks_form' method='get' action='drinks_menu.php'>
        <select id='drinks' name='drinks'>
            <!-- options -->
            <?php
            while ($all_drinks_record = mysqli_fetch_assoc($all_drinks_results)) {
                echo "<option value = '" . $all_drinks_record['drink_id'] . "'>";
                echo $all_drinks_record['Item'];
                echo "</option>";
            }
            ?>
        </select>
        <input type='submit' name='drinks_button' value='Show me the drink information.'>
    </form>
</main>
</body>
</html>
