<?php
$con = mysqli_connect("localhost", "familtonmi", 'quietfruit45', "familtonmi_tuck_shop");
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL:" . mysqli_connect_error();
    die();
}else {
    echo "connected to database";
}
if (isset($_GET['drink_special']['food_special'])) {
    $id = $_GET['drink_special']['food_special'];
} else {
    $id = 1;
}

/* Drinks Query */
$this_drink_special_query = "SELECT * FROM `drink_special` WHERE drink_id ='" . $id . "'";
$this_drink_special_result = mysqli_query($con, $this_drink_special_query);
$this_drink_special_record = mysqli_fetch_assoc($this_drink_special_result);
/* SELECT DrinkID, Item FROM drinks */
$all_drinks_special_query = "SELECT * FROM `drink_special` WHERE drink_id";
$all_drinks_special_results = mysqli_query($con, $all_drinks_special_query);

/* Food Query */
$this_food_special_query = "SELECT food_special.FoodspecialID,food.item,food_special.Day,food_special.Foodspecialprice FROM food_special,food WHERE food.food_id=food_special.food_id AND FoodspecialID= 1";
$this_food_special_result = mysqli_query($con, $this_food_special_query);
$this_food_record = mysqli_fetch_assoc($this_food_special_result);
/* SELECT food_id, Item FROM food */
$all_food_special_query = "SELECT * FROM `food_special` WHERE food_id";
$all_food_special_result = mysqli_query($con, $all_food_special_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>TEAL TUCK SHOP</title>
    <meta charset="utf-8">
    <link rel='stylesheet' type='text/css' href='styles.css'>
</head>

<body>
<header>
    <h1> TEAL TUCK SHOP </h1>
    <nav>
        <ul>
            <a href='index.php'> Home </a>
            <a href='drinks_menu.php'> Drinks </a>
            <a href='food_menu.php'> Food </a>
            <a href='meal_menu.php'> Specials </a>
        </ul>
    </nav>
</header>
<main>
    <h2> Show Certain Things</h2>

    <form action="drinks_menu.php" method="post">
        <input type='submit' name='testquery1' value="Drink Specials">
    </form>

    <form action="food_menu" method="post">
        <input type='submit' name='testquery2' value="Food Specials">
    </form>

    <?php
    if(isset($_POST['testquery1']))
    {
        $result=mysqli_query($con, "SELECT * FROM drinks");
        if(mysqli_num_rows($result)!=0)
        {
            while($test = mysqli_fetch_array($result))
            {
                $id = $test['DrinkID'];
                echo "<table>";
                echo "<tr>";
                echo "<tr>". $test['Item']. "</tr>";
                echo "<tr>". $test['Cost']. "</tr>";
                echo "</tr>";
                echo "</table>";
            }
        }
    }
    ?>


    <?php
    if(isset($_POST['testquery2']))
    {
        $result=mysqli_query($con, "SELECT * FROM food");
        if(mysqli_num_rows($result)!=0)
        {
            while($test = mysqli_fetch_array($result))
            {
                $id = $test['CustomerID'];
                echo "<table>";
                echo "<tr>";
                echo "<tr>". $test['FName']. "</tr>";
                echo "<tr>". $test['LName']. "</tr>";
                echo "</tr>";
                echo "</table>";
            }
        }
    }
    ?>

</main>
</body>
</html>